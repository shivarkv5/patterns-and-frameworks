
import java.util.*;

/*
 * Students.java
 *
 * @author  merry
 */
public class Students
{
   private TreeMap<Short, Student> stuMap;

   public Students()
   {
      stuMap = new TreeMap<Short, Student>();
   }

   public void addStu(Student stu)
   {
      stuMap.put(new Short(stu.getStudentId()), stu);
   }

   public void removeStu(Student stu)
   {
      stuMap.remove(new Short(stu.getStudentId()));
   }

   public Student getStu(short id)
   {
      return stuMap.get(new Short(id));
   }

   public Iterator<Student> listStudents()
   {
      return allStudents().iterator();
   }

   private Collection<Student> allStudents()
   {
      return stuMap.values();
   }
}
