package com.example.ParametersDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParametersDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
